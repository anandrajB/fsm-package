
#  base_enum 
# while stage = False:
    # v = 1
    # try:
    #     for item in itens:
    #         b = itens[1 + v]
    #         print(b)
    #         c = b
    #         if b == itens[-1]:
    #             break
    #     print("the value is ", c)
    # except:
    #     print("cant do this ")




 # trans_length = int(stage) - int(gets_model.sign_required)
                        # if trans_length != 1 and int(stage) == int(gets_sign):
                        #     trans_length_var = trans_length - 1
                        # else:
                        # while stage == True:
                        #     try:
                        #             for item in sign_list:
                        #                 b = sign_list[1 + trans_length_var]
                        #                 print(b)
                        #                 c = b
                        #                 if b == sign_list[-1]:
                        #                     break
                        #             print("the value is ", c)
                        #     except:
                        #             print("cant do this ")
                        #     return None